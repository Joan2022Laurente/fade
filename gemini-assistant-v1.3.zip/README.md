# 🤖 Gemini AI Assistant para VSCode

Extensión de VSCode que te permite seleccionar texto o código y enviarlo silenciosamente a la API de Google Gemini. La respuesta se copia automáticamente al portapapeles.

---

## 🚀 Instalación

### Opción 1: Instalar el .vsix directamente
1. Abre VSCode
2. Ve a **Extensiones** (`Ctrl+Shift+X`)
3. Haz clic en los **`...`** (tres puntos) arriba a la derecha
4. Selecciona **"Install from VSIX..."**
5. Selecciona el archivo `gemini-assistant-1.0.0.vsix`

### Opción 2: Compilar desde código fuente
```bash
npm install
npm run compile
```

---

## 🔑 Configuración de API Key

1. Obtén tu API Key gratis en: **https://aistudio.google.com/**
2. En VSCode, usa `Ctrl+Shift+P` → busca **"Gemini: Configurar API Key"**
3. Ingresa tu API Key y presiona Enter

---

## ⌨️ Atajos de teclado

| Atajo | Acción |
|-------|--------|
| `Ctrl+Shift+G` | Consulta general (análisis del texto seleccionado) |
| `Ctrl+Shift+E` | Explicar la selección |
| `Ctrl+Shift+I` | Mejorar / optimizar el código |
| `Ctrl+Shift+D` | Depurar / encontrar bugs |

> En Mac reemplaza `Ctrl` por `Cmd`

---

## 🖱️ Menú contextual

También puedes hacer **clic derecho** sobre el texto seleccionado para ver las opciones de Gemini en el menú contextual.

---

## ⚙️ Configuración

Ve a **Archivo → Preferencias → Configuración** y busca **"Gemini"**:

| Opción | Descripción | Valor por defecto |
|--------|-------------|-------------------|
| `gemini-assistant.apiKey` | Tu API Key de Gemini | _(vacío)_ |
| `gemini-assistant.model` | Modelo a usar | `gemini-2.0-flash` |
| `gemini-assistant.defaultPrompt` | Prompt del comando principal | _(análisis general)_ |
| `gemini-assistant.showNotifications` | Mostrar notificaciones | `true` |
| `gemini-assistant.includeLanguageContext` | Incluir lenguaje del archivo | `true` |

### Modelos disponibles
- `gemini-2.0-flash` ⚡ (recomendado - rápido y capaz)
- `gemini-2.0-flash-lite` 🪶 (más ligero)
- `gemini-1.5-pro` 🧠 (más potente)
- `gemini-1.5-flash` ⚡ (anterior)

---

## 📋 Uso

1. Selecciona texto o código en cualquier archivo
2. Usa uno de los atajos de teclado (ej: `Ctrl+Shift+G`)
3. La barra de estado mostrará `⟳ Gemini...` mientras procesa
4. Al terminar, verás `✅ Gemini: Respuesta copiada al portapapeles`
5. Pega con `Ctrl+V` donde necesites la respuesta

---

## 🔒 Privacidad

- La API Key se guarda en la configuración global de VSCode
- El texto seleccionado se envía directamente a la API de Google Gemini
- No se almacena ningún dato localmente más allá de la API Key

---

## 📝 Licencia

MIT
