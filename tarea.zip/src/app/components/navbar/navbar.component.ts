import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
      <div class="container">
        <a class="navbar-brand fw-bold" routerLink="/home">App</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" routerLink="/home" routerLinkActive="active">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/estadisticas" routerLinkActive="active">Estadísticas</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/configuracion" routerLinkActive="active">Configuración</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/notificaciones" routerLinkActive="active">Notificaciones</a>
            </li>
          </ul>
          <div class="d-flex align-items-center gap-2">
            <span class="text-white-50 small">{{ session?.name }}</span>
            <button class="btn btn-outline-light btn-sm" (click)="logout()">Salir</button>
          </div>
        </div>
      </div>
    </nav>
  `
})
export class NavbarComponent {
  session: any;

  constructor(private auth: AuthService, private router: Router) {
    this.session = this.auth.getSession();
  }

  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
