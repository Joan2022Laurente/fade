import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="auth-wrapper">
      <div class="card auth-card">
        <div class="card-body">
          <div class="text-center mb-4">
            <h4 class="fw-bold">Crear Cuenta</h4>
            <p class="text-muted small">Regístrate para continuar</p>
          </div>
          <div *ngIf="success" class="alert alert-success py-2 small">{{ success }}</div>
          <div *ngIf="error" class="alert alert-danger py-2 small">{{ error }}</div>
          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="mb-3">
              <label class="form-label small fw-semibold">Nombre</label>
              <input type="text" class="form-control" formControlName="name"
                [class.is-invalid]="f['name'].invalid && f['name'].touched" placeholder="Tu nombre">
              <div class="invalid-feedback">Nombre requerido.</div>
            </div>
            <div class="mb-3">
              <label class="form-label small fw-semibold">Email</label>
              <input type="email" class="form-control" formControlName="email"
                [class.is-invalid]="f['email'].invalid && f['email'].touched" placeholder="email@ejemplo.com">
              <div class="invalid-feedback">Email inválido.</div>
            </div>
            <div class="mb-4">
              <label class="form-label small fw-semibold">Contraseña</label>
              <input type="password" class="form-control" formControlName="password"
                [class.is-invalid]="f['password'].invalid && f['password'].touched" placeholder="••••••">
              <div class="invalid-feedback">Mínimo 6 caracteres.</div>
            </div>
            <button type="submit" class="btn btn-primary w-100 fw-semibold">Registrarse</button>
          </form>
          <p class="text-center small mt-3 mb-0">
            ¿Ya tienes cuenta? <a routerLink="/login" class="text-decoration-none">Inicia sesión</a>
          </p>
        </div>
      </div>
    </div>
  `
})
export class RegisterComponent {
  form: FormGroup;
  error = '';
  success = '';

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  get f() { return this.form.controls; }

  submit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const { name, email, password } = this.form.value;
    if (this.auth.register(name, email, password)) {
      this.success = '¡Cuenta creada! Redirigiendo...';
      setTimeout(() => this.router.navigate(['/login']), 1500);
    } else {
      this.error = 'El email ya está registrado.';
    }
  }
}
