import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="auth-wrapper">
      <div class="card auth-card">
        <div class="card-body">
          <div class="text-center mb-4">
            <h4 class="fw-bold">Iniciar Sesión</h4>
            <p class="text-muted small">Accede a tu cuenta</p>
          </div>
          <div *ngIf="error" class="alert alert-danger py-2 small">{{ error }}</div>
          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="mb-3">
              <label class="form-label small fw-semibold">Email</label>
              <input type="email" class="form-control" formControlName="email"
                [class.is-invalid]="f['email'].invalid && f['email'].touched" placeholder="email@ejemplo.com">
              <div class="invalid-feedback">Email inválido.</div>
            </div>
            <div class="mb-4">
              <label class="form-label small fw-semibold">Contraseña</label>
              <input type="password" class="form-control" formControlName="password"
                [class.is-invalid]="f['password'].invalid && f['password'].touched" placeholder="••••••">
              <div class="invalid-feedback">Mínimo 6 caracteres.</div>
            </div>
            <button type="submit" class="btn btn-primary w-100 fw-semibold">Entrar</button>
          </form>
          <p class="text-center small mt-3 mb-0">
            ¿Sin cuenta? <a routerLink="/register" class="text-decoration-none">Regístrate</a>
          </p>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent {
  form: FormGroup;
  error = '';

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {
    this.form = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  get f() { return this.form.controls; }

  submit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const { email, password } = this.form.value;
    if (this.auth.login(email, password)) {
      this.router.navigate(['/home']);
    } else {
      this.error = 'Credenciales incorrectas.';
    }
  }
}
