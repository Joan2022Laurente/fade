import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersService } from '../../services/users.service';
import { NavbarComponent } from '../../components/navbar/navbar.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, NavbarComponent],
  template: `
    <app-navbar></app-navbar>
    <div class="container py-5">
      <div class="mb-4">
        <h5 class="fw-bold mb-1">Usuarios</h5>
        <p class="text-muted small mb-0">Lista de usuarios del sistema</p>
      </div>
      <div *ngIf="loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status"></div>
      </div>
      <div class="row g-3" *ngIf="!loading">
        <div class="col-12 col-sm-6 col-lg-4" *ngFor="let user of users">
          <div class="card user-card shadow-sm h-100">
            <div class="card-body d-flex align-items-start gap-3">
              <div class="avatar">{{ user.name.charAt(0) }}</div>
              <div class="overflow-hidden">
                <p class="fw-semibold mb-0 text-truncate">{{ user.name }}</p>
                <p class="text-muted small mb-1 text-truncate">{{ user.email }}</p>
                <span class="badge bg-primary-subtle text-primary small">{{ user.company.name }}</span>
              </div>
            </div>
            <div class="card-footer bg-transparent border-top-0 px-3 pb-3">
              <div class="d-flex gap-3 text-muted" style="font-size:0.78rem">
                <span>{{ user.phone.split(' ')[0] }}</span>
                <span>{{ user.website }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent implements OnInit {
  users: any[] = [];
  loading = true;

  constructor(private usersService: UsersService) {}

  ngOnInit() {
    this.usersService.getUsers().subscribe({
      next: data => { this.users = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }
}
